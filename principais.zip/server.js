const express = require('express');
const app = express();
const path = require('path');
const dotenv = require('dotenv');
dotenv.config();

// Config MenteBrilhante
const PORTA = process.env.PORT || 9080;
const HOST = '0.0.0.0'; // Libera acesso pra outros PCs na rede

app.use(express.json());
app.use(express.static(__dirname));

// Rotas
const appRoutes = require('./app.js');
app.use('/api', appRoutes);

// Rota principal - abre o index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Inicia servidor MenteBrilhante
app.listen(PORTA, HOST, () => {
  console.log(`✨ MenteBrilhante rodando em http://${HOST}:${PORTA}`);
  console.log(`Acessa: http://localhost:${PORTA}`);
});
